
var LoginLayer = cc.Layer.extend({
    ctor:function() {
        this._super();
        cc.associateWithNative( this, cc.Layer );
    },
    init:function () {

        //////////////////////////////
        // 1. super init first
        this._super();

        // add a "close" icon to exit the progress. it's an autorelease object
        var closeItem = cc.MenuItemImage.create(
            "loginBtn_n.png",
            "loginBtn_d.png",
            function () {
                cc.log("click login button in loacl.");
            },this);
        closeItem.setAnchorPoint(cc.p(0.5, 0.5));

        var menu = cc.Menu.create(closeItem);
        menu.setPosition(cc.p(0, 0));
        this.addChild(menu, 1);
        closeItem.setPosition(cc.p(150, 120));

        //hello test
        this.helloLabel = cc.LabelTTF.create("this is local layer!", "Arial", 28);
        // position the label on the center of the screen
        this.helloLabel.setPosition(cc.p(130, 60));
        // add the label as a child to this layer
        this.addChild(this.helloLabel, 5);
        return true;
    }

});
